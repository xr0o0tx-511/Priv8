<?php

$db = [
    'db_name' => 'app',
    'db_username' => 'php',
    'db_password' => 'php',
    'db_host' => 'localhost'
];

$mysqli = new mysqli($db['db_host'], $db['db_username'], $db['db_password'],$db['db_name']);
 if ($mysqli->connect_error) {
  die("Connection failed: " . $mysqli->connect_error);
}