    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const content = document.getElementById('content');
        const overlay = document.querySelector('.sidebar-overlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('active');
                content.classList.toggle('active');
                overlay.classList.toggle('active');
            });
        }

        if (overlay) {
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('active');
                content.classList.remove('active');
                overlay.classList.remove('active');
            });
        }

        if (window.innerWidth < 992) {
            document.querySelectorAll('.nav-link').forEach(link => {
                link.addEventListener('click', () => {
                    sidebar.classList.remove('active');
                    content.classList.remove('active');
                    overlay.classList.remove('active');
                });
            });
        }
    </script>

    <style>
        footer {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-top: 1px solid #dee2e6;
            margin-top: 20px;
        }
        #sidebar.active { left: 0; }
        #content.active { margin-left: 250px; transition: margin-left 0.3s ease; }
        .sidebar-overlay {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            z-index: 998;
        }
        .sidebar-overlay.active { display: block; }
    </style>

    <footer>
        &copy; <?= date('Y') ?> My Admin Panel
    </footer>
</body>
</html>
