#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#define RED     "\x1b[31m"
#define GREEN   "\x1b[32m"
#define def     "\033[0m"
//To compile this program use this command -> gcc bank.c -o bank -masm=intel -no-pie -fstack-protector -Wl,-z,norelro

int balance = 20;

char *name = 0;
char *password = 0;
char *username = 0;
char *paw = 0;

void setup(void) {
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
}


void create() {
	printf("Please Enter Your username: ");
	username = malloc(20*sizeof(char));
	fgets(username,20,stdin);
	fgets(username,20,stdin);
        username[strlen(username) -1] = '\0';
	if (strcmp(username,"root") == 0) {
		printf(RED "This user already exists\n" def);
		eXit();
		}
	else {
		char i;
		paw = malloc(20*sizeof(char));
		password =  malloc(20*sizeof(char));
		name = malloc(20*sizeof(char));
		printf("Please Enter Your Password: ");
                fgets(paw,20,stdin);
                paw[strlen(paw)-1] = '\0'; 
                printf(GREEN "Account has been created\n" def);
		printf("Now try login with your account\n");
                auth();}
}
void login() {
	char c[20];
	char yes[] = "yes";
	int val;
	int value;
	printf("\n");
	name = malloc(20*sizeof(char));
	printf("Please Enter Your Username: ");
        fgets(name,20,stdin);
        fgets(name,20,stdin);
        name[strlen(name)-1] = '\0';
	if (strcmp(name,"root") == 0) {
		password = malloc(20*sizeof(char));
		printf("Please Enter Your Password: ");
                fgets(password,20,stdin);
                password[strlen(password)-1] = '\0'; 
		printf(RED "Not Have Permission To Login with root user\n" def);
		printf("Do You Want Return to login or exit ? yes/no: ");
		fgets(c,20,stdin);
		c[strlen(c)-1] = '\0';
		value=strcmp(c,yes);
		if(value == 0) {
			auth();}
		else {
			eXit();}
}
	else if (strcmp(name,username) == 0) {
		password = malloc(20*sizeof(char));
		printf("Please Enter Your Password: ");
                fgets(password,20,stdin);
                password[strlen(password)-1] = '\0';
		if (strcmp(password,paw) == 0) {
                        printf("Welcome %s\n", name);
                        menu_user();}
                else {
                        printf(RED "Password is incorrect\n" def);
                        eXit();}
}
	else {
		printf(RED "Not Found user\n" def);
		eXit();

}
}

void auth() {
	int c;
	printf("\n");
	printf("Welcome To Best Bank\n");
	printf("***version: 1.0***\n\n");
	printf("1- Login\n");
	printf("2- Sign Up\n");
	printf("\n> ");
	scanf("%d", &c);
	switch (c) {
	case 1:
		login();
		break;
	case 2:
		create();
		break;
	default:
            			printf(RED "Invalid Choice.\n" def);
            			}
	
}
void newuser() {
		int value;
		char c[20];
		char yes[] = "yes";
		char newuser[20];
		name = malloc(20*sizeof(char));
		printf("Please Enter Your New Username: ");
	        fgets(name,20,stdin);
		name[strlen(name)-1] = '\0';
		if (strcmp(name,"root") == 0) {
			printf(RED "This user already exists\n" def);
			eXit();
}
		else {
        		printf(GREEN "The Username is Changed Successfully" def "\n");
			printf("Do You Want Return to menu or exit ? yes/no: ");
			fgets(c,20,stdin);
			c[strlen(c)-1] = '\0';
			value=strcmp(c,yes);
			if(value == 0) {
				menu_user();}
			else {
				eXit();}
}
}
void newpass() {
	int value;
	char c[20];
	char yes[] = "yes";
        char newpass[20];
	password = malloc(20*sizeof(char));
        printf("Enter New Password: ");
	fgets(password,20,stdin);
	password[strlen(password)-1] = '\0';
        printf(GREEN "The Password is Changed Successfully" def "\n");
	printf("Do You Want Return to menu or exit ? yes/no: ");
        fgets(c,20,stdin);
        c[strlen(c)-1] = '\0';
        value=strcmp(c,yes);  
        if(value == 0) {
                        menu_user();}
        else {
                        eXit();}

}

void print_balance() {
	char c[20];
	char yes[] = "yes";
	int value;
	printf("Your Balance: %d\n", balance);
	printf("Do You Want Return to menu or exit ? yes/no: ");
        fgets(c,20,stdin);
        c[strlen(c)-1] = '\0';
        value=strcmp(c,yes);  
        if(value == 0) {
                        menu_root();}
        else {
                        eXit();}
}

void add_fin() {
	int add;
	int value;
	char c[20];
	char yes[] = "yes";
	printf("How much money do you want to add: ");
	scanf("%d", &add);
	balance = balance + add;
	printf(GREEN "Done!\n" def);
	printf("Do You Want Return to menu or exit ? yes/no: ");
        fgets(c,20,stdin);
        fgets(c,20,stdin);
        c[strlen(c)-1] = '\0';
        value=strcmp(c,yes);  
        if(value == 0) {
                        menu_root();}
        else {
                        eXit();}

}

void cash_withdrawal() {
	char c[20];
	int value;
	char yes[] = "yes";
	int amount;
	printf("How much money do you want to get: ");
	scanf("%d", &amount);
	balance = balance - amount;
	printf(GREEN "Done!\n" def);
	printf("Do You Want Return to menu or exit ? yes/no: ");
        fgets(c,20,stdin);
        fgets(c,20,stdin);
        c[strlen(c)-1] = '\0';
        value=strcmp(c,yes);  
        if(value == 0) {
                        menu_root();}
        else {
                        eXit();}
         
}

void add_credit() {
	char num_card[20];
	char Expiry_Date[20];
	char cvv[200];
	char num_credit[20];
	printf("Enter Card Number: ");
	fgets(num_card,20,stdin);
	printf("Enter Card Expiry Date: ");
	fgets(Expiry_Date,20,stdin);
	printf("Enter CVV Number: ");
	fgets(cvv,200,stdin);
	printf(cvv);
	printf("Enter Card Name: ");
	gets(num_credit);

}

void eXit() {
	printf(RED "G00d Bye\n" def);
	exit(0);
}

void show_info() {
	printf("username: %s\n",name);
	printf("password: %s\n",password);
	printf(RED "Your account is not activated with us, try to activate the account at the nearest branch to us" def);
	printf("\n");
	menu_user();
}

int menu_root() {
		char choice;
		printf("\n");
		printf("***Welcome To Bank***\n***version: 1.0***\n***Admin Menu***\n\n");
                printf("1- Change Username\n2- Change Password\n3- Show Balance\n4- Add Money\n5- Get amount\n6- Add New Credit Card\n7- exit\n\n> ");
                scanf("%c", &choice);
		getchar();
		switch (choice) {
			case '1':
				newuser();
				break;
			case '2':
				newpass();
				break;
			case '3':
				print_balance();
				break;
			case '4':
				add_fin();
				break;
			case '5':
				cash_withdrawal();
			case '6':
				add_credit();
				break;
			case '7':
				eXit();
				break;
			default:
            			printf(RED "Invalid Choice.\n" def);

}
	return 0;
}


void admin() {
	if(strcmp(name,"root") == 0) {
		printf(GREEN "Success Login with admin user\n" def);
        	menu_root();
}
	else {
		printf(RED "Not Have Permission To Login With admin Account\n" def);
		eXit();
}
}

void remove_user() {
	free(password);
	free(name);
	printf(GREEN "Remove Account is Success\n" def);
	menu_user();
}

int menu_user() {
		char choi;
		printf("\n");
		printf("***Welcome To Bank***\n***version: 1.0***\n\n");
                printf("1- Change Username\n2- Change Password\n3- Login As admin\n4- Remove Account\n5- Login with Other account\n6- Show Information\n7- exit \n\n> ");
                scanf("%c", &choi);
		getchar();
		switch (choi) {
			case '1':
				newuser();
				break;
			case '2':
				newpass();
				break;
			case '3':
				admin();
				break;
			case '4':
				remove_user();
				break;
			case '5':
				auth();
				break;
			case '6':
				show_info();
				break;
			case '7':
				eXit();
				break;
			default:
            			printf(RED "Invalid Choice.\n" def);

}
	return 0;
}
void i() {
	asm("pop r12 ; pop r13 ; ret");
}


int main() {
	setup();
        auth();
	return 0;
}
