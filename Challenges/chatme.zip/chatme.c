#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

typedef struct {
    void (*ptr)(char*);
    char *message;
} NOTES;

NOTES *note;
typedef unsigned long addr;

int menu();
void hello();
void show(char *message);
void sigsegv_handler(int signum);
void sigsegv_handler(int signum) {
  puts("Segmentation fault");
  exit(1);
}

void show(char *message){
        if(message == NULL){
                printf("NULL\n");
        }else{
                printf("%-21s\n",message);
        }
}

int menu(){
        int choice;
		printf("***chatme@chatme.local***\n***Version: beta***");
		printf("\n\n");
        printf("1- Send Email\n");
        printf("2- Delete Email\n");
        printf("3- Check inboxe\n");
        printf("4- Exit\n\n");
        printf("> ");
        scanf("%d", &choice);
        return choice;
}

void hello(){
	printf("%p\n",system);
}

int main(void) {
        note = (NOTES*)malloc(sizeof(NOTES));
        note->ptr = show;
        note->message = NULL;
        setvbuf(stdin, NULL, _IONBF, 0);
        setvbuf(stdout, NULL, _IONBF, 0);
        signal(SIGSEGV, sigsegv_handler);
        while (1){
                switch (menu()) {
                        case 1:
								char name[20];
								char subject[20];
								printf("To: ");
								scanf("%19s",&name);
								printf("Subject: ");
								scanf("%19s",&subject);
								printf("Message: ");
                                note->message = malloc(17);
  	                        	scanf("%16s",note->message);
								printf("[+] Email has been Sent Successfully\n\n");
                                break;
                        case 2:
                                free(note);
								printf("[+] Email has been deleted Successfully\n\n");
                                break;
                        case 3:
								printf("This feature is still under development\n\n");
                                note->ptr(note->message);
                                break;
                        case 4:
                                printf("G00d Bye\n");
                                exit(0);
                                break;
                        case 1337:
                                hello();
                                break;
                        default:
                                printf("invaild Choice\n");
        }
}
        return 0;
}