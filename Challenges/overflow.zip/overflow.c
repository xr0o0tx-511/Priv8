#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#define RED     "\x1b[31m"
#define GREEN   "\x1b[32m"
#define def     "\033[0m"

void login();
void user();
void pass();
void menu();

char* shell = "/bin/sh";


char password[] = "myP@$$w0rd!";
char username[] = "admin";


void login(){
	int value;
	char use[30];
	char pas[30];
	printf("Enter Username: ");
	fgets(use,30,stdin);
	use[strlen(use)-1] = '\0';
	printf("Enter Password: ");
	fgets(pas,30,stdin);
	pas[strlen(pas)-1] = '\0';
	value=strcmp(username,use);
	if(value == 0) {
		int v;
		v=strcmp(password,pas);
		if(v == 0){
 			menu();
		}
		else {
		printf(RED "Username Or Password is incorrect" def);
		}
		}
	else {
		printf(RED "Username Or Password is incorrect" def);
}
}

void user(){
	char pass[30];
	char user[30];
	int value;
	printf("Please Enter Password: ");
	fgets(pass,30,stdin);
	pass[strlen(pass)-1] = '\0';
	value=strcmp(password,pass);
	if(value == 0) {
		printf("Please Enter New Username: ");
		fgets(user,8,stdin);
		printf(GREEN "Username is Changed Successfully\n" def);
		menu();}
	else {
		printf(RED "Password is incorrect" def);
		}
}

void pass(){
	char newpass[30];
	char oldpass[50];
	int value;
	printf("Please Enter Old Password: ");
	fgets(oldpass,30,stdin);
	oldpass[strlen(oldpass)-1] = '\0';
	value=strcmp(password,oldpass);
	if(value == 0) {
			printf("Please Enter New Password: ");
			gets(newpass);
		}
	else {
		printf(RED "Password is incorrect" def);
}
}

void menu(){
	printf("\n");
        char choice;
        printf("1- Change Username\n");
        printf("2- Change Password\n");
        printf("3- Exit\n\n");
        printf("> ");
        scanf("%c",&choice);
        getchar();
        switch (choice) {
                case '1':
                        user();
                        break;
                case '2':
                        pass();
                        break;
                case '3':
                        printf("Good By *_*");
                        exit(0);
                        break;
                default:
                        printf("Invaild Choice :(");
                        break;
        }
}


int main(){
	 login();
	write(1,"",1);
	asm("pop rax ; ret");
	asm("syscall");
	return 0;
}

