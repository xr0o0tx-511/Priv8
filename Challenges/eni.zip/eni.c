#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

struct chunk { 
    char *data;
    size_t size;
};

int check_of_chunk[20] = {0};
int idx = 0;
size_t size;

int get_int();

int get_int(){
    char num[10];
    int res;
    read(0,num,10);
    res = atoi(num);
    return res;
}

char username[30];
struct chunk table[20];

int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    printf("Enter your username: ");
    read(0,username,30);
    while(1){
    int choice;
    printf("\n1- Alloc\n2- Edit\n3- Free\n4- View\n> ");
    choice = get_int();
    switch (choice){
        case 1:
            for(int i =0;i< 20;i++){
                if(!check_of_chunk[i]){
                    printf("size: ");
                    scanf("%ld",&size);
                    table[i].size = size;
                    table[i].data = (char *)malloc(size);
                    check_of_chunk[i] = 1;
                    printf("Created Index at %d\n",i);
                    break;

                }
            }
            break;
        case 2:
            printf("Index: ");
            idx = get_int();
            if(check_of_chunk[idx]){
                printf("Data: ");
                table[idx].data[read(0,table[idx].data,table[idx].size)] = '\0';

            }else{
                printf("Not Found The Index\n");
            } 
            break;
        case 3:
            printf("Index: ");
            idx = get_int();
            if(check_of_chunk[idx]){
            free(table[idx].data);
            check_of_chunk[idx] = 0;
            }else{
                printf("Not Found The Index\n");
            }
            break;
        case 4:
            printf("Index: ");
            scanf("%d",&idx);
            write(1,table[idx].data,table[idx].size);   
            break;
    
        default:
            printf("Invaild Choice\n");

    }

}}