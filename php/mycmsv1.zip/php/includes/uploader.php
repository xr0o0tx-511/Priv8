<?php
require_once __DIR__."/../config/app.php";
require_once __DIR__."/../config/db.php";

function upload($file) {
    $upload_dir = __DIR__ . "/../images/";
    $public_path = "images/";
    $max_size = 10 * 1024 * 1024;
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    
    if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Upload error: ' . ($file['error'] ?? 'No file uploaded'));
    }
    
    if (!file_exists($file['tmp_name'])) {
        throw new Exception('Temporary file no longer exists. Please try again.');
    }
    
    $fileMimeType = mime_content_type($file['tmp_name']);
    if (!in_array($fileMimeType, $allowed_types)) {
        throw new Exception('Only JPG, PNG and GIF files are allowed.');
    }
    
    if ($file['size'] > $max_size) {
        throw new Exception('File size exceeds 10MB limit.');
    }
    
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    $allowed_extensions = [
        'image/jpeg' => ['jpg', 'jpeg'],
        'image/png' => ['png'], 
        'image/gif' => ['gif']
    ];
    
    if (!isset($allowed_extensions[$fileMimeType]) || !in_array($extension, $allowed_extensions[$fileMimeType])) {
        throw new Exception('File extension does not match file type.');
    }
    
    if (!is_dir($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            throw new Exception('Could not create upload directory.');
        }
    }
    
    $newFileName = uniqid() . '_' . time() . "." . $extension;
    $target_file = $upload_dir . $newFileName;
    
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        return [
            'success' => true,
            'file_path' => $target_file,
            'public_url' => $public_path . $newFileName,
            'file_name' => $newFileName
        ];
    } else {
        throw new Exception('Failed to move uploaded file.');
    }
}
?>