#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char *table[10];
int idx = 0;

void alloc();
void delete();
void check();
void view();
void hidden();

void alloc(){
    unsigned long size;
    printf("Index: ");
    scanf("%d",&idx);
    if(idx <= 10){
        printf("size: ");
        scanf("%ld",&size);
        table[idx] = (char *)malloc(size);
        printf("Data: ");
        getchar();
        fgets(table[idx],size,stdin);
    }else{
        printf("Erorr The Index is greater than 10");
    }
}

void delete(){  
    printf("Index: ");
    scanf("%d",&idx);
    free(table[idx]);
}

void view(){
    printf("Index: ");
    scanf("%d",&idx);
    write(1,table[idx],sizeof(table[idx]));
}

int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    while(1){
    int choice;
    printf("\n1- Alloc\n2- Free\n3- View\n> ");
    scanf("%d",&choice);
    switch (choice){
        case 1:
            alloc();
            break;
        case 2:
            delete();
            break;
        case 3:
            view();
            break;

        default:
            printf("Invaild Choice\n");

    }

}}