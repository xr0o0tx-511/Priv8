<?php 
$title = "Registeration Page";
require_once 'template/header.php'; 
require 'classes/Service.php';
require 'classes/Product.php';

$NameError = $EmailError = $PasswordError = $ConfirmPasswordError = "";
$name = $email = $password = $confirm_password = "";
$found = false;

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = trim(FilterString($_POST['name']));
    if(empty($name)){
        $NameError = "Your name is required";
    }

    $stmt = $mysqli->prepare("SELECT * FROM users WHERE name = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows > 0){ 
        $NameError = "Username already taken. Try another one";
        $found = true;
    };

    if(!FilterEmail($_POST['email'])){
        $EmailError = "A valid email is required";
    } else {
        $email = FilterEmail($_POST['email']);
    }

    $stmt = $mysqli->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if($stmt->num_rows > 0){ 
        $EmailError = "Email already taken. Try another one";
        $found = true;
    };

    $password = trim(FilterString($_POST['password']));
    if(empty($password)){
        $PasswordError = "Your password is required";
        $found = true;
    }
    $confirm_password = trim(FilterString($_POST['confirm_password']));
    if(empty($confirm_password)){
        $ConfirmPasswordError = "Your password is required";
        $found = true;
    }else{
        if($confirm_password != $password){
            $ConfirmPasswordError = "Passwords do not match";
            $found = true;
        }
    }


    if($found == False){
        $hash_password = password_hash($password,PASSWORD_DEFAULT);
        $role = "user";
        $sql = "insert into users (email,name,role,password) values (?,?,?,?)";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("ssss", $email,$name,$role,$hash_password);
        $stmt->execute();
        echo "Created Account Succeefully";
        header("Location: /php/login.php");
    }

};


?>

<h1>Registeration</h1>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" value="<?php echo $name?>" id="name" name="name">
        <span class="text-danger"><?php echo $NameError?></span>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" value="<?php echo $email?>" id="email" name="email">
        <span class="text-danger"><?php echo $EmailError?></span>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" value="<?php echo $password?>" id="password" name="password">
        <span class="text-danger"><?php echo $PasswordError?></span>
    </div>
    <div class="mb-3">
        <label for="confirm_password" class="form-label">Confirm Password</label>
        <input type="confirm_password" class="form-control" value="<?php echo $confirm_password?>" id="confirm_password" name="confirm_password">
        <span class="text-danger"><?php echo $ConfirmPasswordError?></span>
    </div>

    <div class="form-group">
        <button type="submit" class="btn btn-success">Submit</button>
        <a href="/php/login.php">Do you have Account?</a>
    </div>

</form>

<?php require_once 'template/footer.php'; ?>