<?php
require_once 'template/header.php';

$name = $description = $price = "";
$NameError = $DescriptionError = $PriceError = $ImageError = "";

if ($_SESSION['role'] !== 'admin') {
    echo "Only Admin Can Access this page";
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    
    $stmt = $mysqli->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($image_path);
    $stmt->fetch();
    $stmt->close();
    
    $stmt = $mysqli->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    
    if (!empty($image_path)) {
        $file_path = __DIR__ . '/../' . $image_path;
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }
    
    header("Location: products.php");
    exit;
}

$products = $mysqli->query("SELECT * FROM products")->fetch_all(MYSQLI_ASSOC);

if (isset($_GET['update'])) {
    $id = (int) $_GET['update'];
    $stmt = $mysqli->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $new_name = trim(FilterString($_POST['name']));
        $new_description = trim(FilterString($_POST['description']));
        $new_price = trim(FilterString($_POST['price']));
        $img_path = $product['image'];

        if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] == 0) {
            try {
                $upload_result = upload($_FILES['image']);
                if ($upload_result['success']) {
                    $img_path = "images/" . $upload_result['file_name'];
                    
                    if (!empty($product['image']) && $product['image'] !== $img_path) {
                        $old_file_path = __DIR__ . '/../' . $product['image'];
                        if (file_exists($old_file_path)) {
                            unlink($old_file_path);
                        }
                    }
                }
            } catch (Exception $e) {
                $ImageError = $e->getMessage();
            }
        }

        if (empty($ImageError)) {
            $stmt = $mysqli->prepare("SELECT * FROM products WHERE name = ? AND id != ?");
            $stmt->bind_param("si", $new_name, $id);
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows > 0) { 
                $NameError = "Name already taken";
            } else {
                $stmt = $mysqli->prepare("UPDATE products SET name=?, description=?, price=?, image=? WHERE id=?");
                $stmt->bind_param("ssdsi", $new_name, $new_description, $new_price, $img_path, $id);
                $stmt->execute();
                $stmt->close();
                
                header("Location: products.php?update={$id}");
                exit;
            }
            $stmt->close();
        }
    }
}

if (isset($_GET['add'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim(FilterString($_POST['name']));
        $description = trim(FilterString($_POST['description']));
        $price = trim(FilterString($_POST['price']));
        $img_path = "";

        if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] == 0) {
            try {
                $upload_result = upload($_FILES['image']);
                if ($upload_result['success']) {
                    $img_path = "images/" . $upload_result['file_name'];
                }
            } catch (Exception $e) {
                $ImageError = $e->getMessage();
            }
        } else {
            $ImageError = "Image is required";
        }

        if (empty($ImageError)) {
            $stmt = $mysqli->prepare("SELECT * FROM products WHERE name = ?");
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows > 0) {
                $NameError = "Name already taken";
            } else {
                $stmt = $mysqli->prepare("INSERT INTO products (name, description, price, image) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssds", $name, $description, $price, $img_path);
                if ($stmt->execute()) {
                    header("Location: products.php?success=1");
                    exit;
                } else {
                    $PriceError = "Failed to add product";
                }
            }
            $stmt->close();
        }
    }
}
?>

<?php if(!isset($_GET['update']) && !isset($_GET['add'])): ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Products Management</h2>
        <a href="products.php?add=1" class="btn btn-success">
            <i class="fas fa-plus"></i> Add New Product
        </a>
    </div>

    <?php if(isset($_GET['success'])): ?>
        <div class="alert alert-success">Product added successfully!</div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($products as $product): ?>
                        <tr>
                            <td><?= $product['id']; ?></td>
                            <td><?= htmlspecialchars($product['name']); ?></td>
                            <td><?= htmlspecialchars($product['description']); ?></td>
                            <td>$<?= number_format($product['price'], 2); ?></td>
                            <td>
                                <?php if(!empty($product['image'])): ?>
                                    <img src="/php/<?= htmlspecialchars($product['image']); ?>" width="80" height="80" style="object-fit: cover;">
                                <?php else: ?>
                                    <span class="text-muted">No image</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="?update=<?= $product['id']; ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="?delete=<?= $product['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?')" class="btn btn-danger btn-sm">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(isset($_GET['update'])): ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Update Product</h4>
                </div>
                <div class="card-body">
                    <form action="products.php?update=<?= $product['id']; ?>" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($product['name']); ?>" required>
                            <span class="text-danger"><?= $NameError ?></span>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3" required><?= htmlspecialchars($product['description']); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" step="0.01" class="form-control" name="price" value="<?= htmlspecialchars($product['price']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Image</label>
                            <input type="file" class="form-control" name="image" accept="image/*">
                            <?php if(!empty($product['image'])): ?>
                                <div class="mt-2">
                                    <img src="/php/<?= htmlspecialchars($product['image']); ?>" width="100" class="img-thumbnail">
                                    <small class="text-muted d-block">Current image</small>
                                </div>
                            <?php endif; ?>
                            <span class="text-danger"><?= $ImageError ?></span>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Update Product</button>
                            <a href="products.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(isset($_GET['add'])): ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0">Add New Product</h4>
                </div>
                <div class="card-body">
                    <form action="products.php?add=1" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($name); ?>" required>
                            <span class="text-danger"><?= $NameError ?></span>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3" required><?= htmlspecialchars($description); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" step="0.01" class="form-control" name="price" value="<?= htmlspecialchars($price); ?>" required>
                            <span class="text-danger"><?= $PriceError ?></span>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Image</label>
                            <input type="file" class="form-control" name="image" accept="image/*" required>
                            <span class="text-danger"><?= $ImageError ?></span>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success">Add Product</button>
                            <a href="products.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once 'template/footer.php'; ?>