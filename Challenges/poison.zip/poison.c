#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int idx = 0;
int size_of_table[20] = {0};
int number_of_tables = 0;
int check_of_chunk[20] = {0};
char *table[20];

void alloc();
void delete();
void edit();
void view();
int get_int();

unsigned long size;


void alloc(){
        if(number_of_tables <= 20){
            for(int i = 0;i <= 20;i++){
            if(!check_of_chunk[i]){
                printf("size: ");
                scanf("%ld",&size);
                size_of_table[i] = size;
                table[i] = (char *)malloc(size);
                check_of_chunk[i] = 1;
                printf("Created Chunk at index %d\n",i);
                ++number_of_tables;
                break;
            }
                }
            }else{
                printf("All chunks uesd :(\n");
                }
        }


void delete(){  
    printf("Index: ");
    idx = get_int();
    if(idx >= 0 && idx <= 20){
            if(table[idx]){
                free(table[idx]);
                table[idx] = NULL;
                printf("The Chunk Removed Success\n");
            }else{
                printf("This Index is already Free`d\n");
            }
    }else{
        printf("Not Found The Index\n");
    }
}

void edit(){
    printf("Index: ");
    idx = get_int();
    if(idx >= 0 || idx <= 20){
        if(table[idx]){
            printf("Data: ");
            int string_length=read(0,table[idx],size_of_table[idx]);
            table[idx][string_length]='\0';
        }else{
            printf("can't edit a free chunk\n");
        }
    }else{
        printf("Not Found The chunk\n");
    } 
}

void view(){
    printf("Index: ");
    idx = get_int();
    if(idx >= 0 || idx <= 20){
        printf("Data: ");
        write(1,table[idx],size_of_table[idx]);
    }else{
        printf("Not Found The chunk\n");
    } 
}

int get_int(){
    char num[10];
    int res;
    read(0,num,10);
    res = atoi(num);
    return res;
}

int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    while(1){
    int cho;
    printf("\n1- Alloc\n2- Edit\n3- Free\n4- View\n\n> ");
    cho = get_int();
    switch (cho){
        case 1:
            alloc();
            break;
        case 2:
            edit();
            break;
        case 3:
            delete();
            break;
        case 4:
            view();
            break;

        default:
            printf("Invaild Choice\n");

    }

}}