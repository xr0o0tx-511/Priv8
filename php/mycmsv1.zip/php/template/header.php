<?php
require_once __DIR__."/../config/app.php";
require_once __DIR__."/../config/db.php";
require_once __DIR__.'/../includes/filtering.php';
require_once __DIR__.'/../includes/uploader.php';

error_reporting($config['display_errors']);
ini_set('display_errors', $config['display_errors']);
session_start();

if (!isset($_SESSION['id']) && isset($_COOKIE['staylogge'])) {
    $token = $_COOKIE['staylogge'];

    $stmt = $mysqli->prepare("SELECT id, name, role FROM users WHERE token = ? LIMIT 1");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows === 1){
        $data = $result->fetch_assoc();
        $_SESSION['id'] = $data['id'];
        $_SESSION['name'] = $data['name'];
        $_SESSION['role'] = $data['role'];
    } else {
        setcookie("staylogge", "", time() - 3600, "/");
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html dir="<?php echo $config['dir'];?>" lang="<?php echo $config['lang'];?>">
<head>
    <title><?php echo $config['app_name'] . " | " . $title?></title>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="/php/index.php"><?php echo $config['app_name']; ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link <?php echo ($title === 'Home') ? 'active' : ''; ?>" href="/php/index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo ($title === 'Contact') ? 'active' : ''; ?>" href="/php/contact.php">Contact</a>
        </li>
      </ul>

      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
  <?php if(isset($_SESSION['id'])): ?>
      <li class="nav-item">
          <a class="nav-link" href="/php/profile.php">Profile (<?php echo htmlspecialchars($_SESSION['name']); ?>)</a>
      </li>
      <?php if($_SESSION['role'] === 'admin'): ?>
          <li class="nav-item">
              <a class="nav-link" href="/php/admin/index.php">Admin Dashboard</a>
          </li>
      <?php endif; ?>
      <li class="nav-item">
          <a class="nav-link" href="/php/logout.php">Logout</a>
      </li>
  <?php else: ?>
      <li class="nav-item">
          <a class="nav-link" href="/php/login.php">Login</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="/php/register.php">Register</a>
      </li>
  <?php endif; ?>
</ul>
    </div>
  </div>
</nav>
<div class="container mt-4">
