<?php 
$title = "Home Page";
require_once 'template/header.php'; 
require 'classes/Service.php';
require 'classes/Product.php';

$sv = new Service;
$productObj = new Product;

$products = $mysqli->query("SELECT * FROM products")->fetch_all(MYSQLI_ASSOC);
$services = $mysqli->query("SELECT * FROM services")->fetch_all(MYSQLI_ASSOC);
?>

<?php if($sv->available): ?>
<h1 class="mb-4">Welcome to our website</h1>

<div class="row">
    <?php foreach($products as $product): ?>
        <div class="col-md-4">
            <div class="card mb-3">
                <h4 class="card-header"><?= htmlspecialchars($product['name']); ?></h4>
                <div class="card-body text-center">
                    <?php if(!empty($product['image'])): ?>
                        <img class="img-fluid mb-2" src="/php/<?= htmlspecialchars($product['image']); ?>" alt="<?= htmlspecialchars($product['name']); ?>" style="width: 100%; height: 200px; object-fit: contain;">
                    <?php endif; ?>
                    <p class="card-text">Description: <?= htmlspecialchars($product['description']); ?></p>
                    <p class="card-text">Price: $<?= number_format($sv->tax_calculation($product['price']), 2); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<div class="row mt-4">
    <?php foreach($services as $service): ?>
        <div class="col-md-4">
            <div class="card mb-3">
                <h4 class="card-header"><?= htmlspecialchars($service['name']); ?></h4>
                <div class="card-body">
                    <p class="card-text">Price: $<?= number_format($sv->tax_calculation($service['price']), 2); ?></p>
                    <p class="card-text">Available Days: <?= htmlspecialchars($service['days']); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php endif; ?>
<?php require_once 'template/footer.php'; ?>
