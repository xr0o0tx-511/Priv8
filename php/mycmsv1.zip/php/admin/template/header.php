<?php 
require_once __DIR__."/../../config/app.php";
require_once __DIR__."/../../config/db.php";
require_once __DIR__.'/../../includes/filtering.php';
require_once __DIR__.'/../../includes/uploader.php';

session_start();
error_reporting($config['display_errors']);
ini_set('display_errors', $config['display_errors']);


if (isset($_SESSION['id'], $_SESSION['name'], $_SESSION['role']) && $_SESSION['role'] === 'admin') {
 

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; }
        header { background: #333; color: #fff; padding: 10px; text-align: center; }
        nav { background: #555; color: #fff; padding: 10px; width: 200px; float: left; height: 100vh; }
        nav a { color: #fff; display: block; padding: 5px 0; text-decoration: none; }
        main { margin-left: 210px; padding: 20px; }
        footer { clear: both; background: #333; color: #fff; text-align: center; padding: 10px; position: fixed; bottom: 0; width: 100%; }
    </style>
</head>
<body>

<header>
    <h1>Admin Panel</h1>
</header>

<nav>
    <a href="index.php">Dashboard</a>
    <a href="users.php">Users</a>
    <a href="products.php">Products</a>
    <a href="services.php">Services</a>
    <a href="messages.php">Messages</a>
    <a href="settings.php">Settings</a>
    <a href="../logout.php">Logout</a>
</nav>
<?php }else{
    echo "Only Admin Can Access this page";
    die();   
}; ?>