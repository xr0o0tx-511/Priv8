#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

struct chunk { 
    char name[8];
    char *ptr;
};

int idx = 0;
size_t size;

int number_of_tables = 0;
int size_of_table[20] = {0};
int check_of_chunk[20] = {0};

int get_int();

struct chunk table[20];

int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    while(1){
    int choice;
    int i;
    printf("\n1- Alloc\n2- Free\n3- View\n> ");
    choice = get_int();
    switch (choice){
        case 1:
            printf("Size: ");
            scanf("%ld",&size);
            if(size > 0x3E8){
                printf("The Size Most Be smaller then 0x3E8\n");
            }else if(number_of_tables <= 20){
                for(i = 0;i < 20;i++){
                    if(!table[i].ptr){
                        size_of_table[i] = size;
                        table[i].ptr = (char *)malloc(size);
                        check_of_chunk[i] = 1;
                        printf("Data: ");
                        read(0,table[i].ptr,size_of_table[i]);
                        printf("Chunk Name: ");
                        read(0,table[i].name,0x10);
                        printf("Created Chunk at index %d\n",i);
                        ++number_of_tables;
                        break;
                    }
                }
            
            }

            break;
        case 2:
            printf("Index: ");
            scanf("%d",&idx);
            if(check_of_chunk[idx]){
                free(table[idx].ptr);
                check_of_chunk[idx] = 0;
            }else{
                printf("Not Found This Chunk\n");
            }
            break;
        case 3:
            printf("Index: ");
            scanf("%d",&idx);
            if(idx >= 0 && idx <= 20){
                printf("Data: %s",table[idx].ptr);
            }else {
                printf("Invalid Index\n");
            }
            break;

        default:
            printf("Invaild Choice\n");

    }
}
    return 0;
}

int get_int(){
    char num[10];
    int res;
    read(0,num,10);
    res = atoi(num);
    return res;
}