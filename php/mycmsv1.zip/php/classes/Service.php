<?php

class Service {
    public $available;
    public $tax_rate = 0.05;


    // constructer
    public function __construct(){
        $this->available = true;
    }

    // destructor
    public function __destruct()
    {
        
    }

    public function all(){
        return[
            ['name' => 'Consultation','price' => 500,"days" => ["Sun","Mon"]],
            ['name' => 'Training','price' => 300,"days" => ["Tue","Wed"]],
            ['name' => 'Design','price' => 100,"days" => ["Thu","Fri"]],
        ];
    }

    public function tax_calculation($price){
        if($this->tax_rate > 0){
            $price = $price + ($price * $this->tax_rate);
            return $price;
        }else{
            return $price;
        }
    }

}