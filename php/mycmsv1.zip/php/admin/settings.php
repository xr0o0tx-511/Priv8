<?php
$title = "Settings";
require_once 'template/header.php';

if ($_SESSION['role'] !== 'admin') {
    echo "Only Admin Can Access this page";
    exit;
}

$configFile = __DIR__."/../config/app.php";
$currentConfig = [
    'app_name' => 'Service App', 
    'dir' => 'ltr',
    'lang' => 'en',
    'admin_email' => 'admin@admin.local',
    'app_url' => 'http://127.0.0.1/php/'
];

if (file_exists($configFile)) {
    include $configFile;
}

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newConfig = [
        'app_name' => trim($_POST['app_name']),
        'dir' => trim($_POST['dir']),
        'lang' => trim($_POST['lang']),
        'admin_email' => trim($_POST['admin_email']),
        'app_url' => trim($_POST['app_url']),
        'display_errors' => trim($_POST['display_errors']),
        'error_reporting' => trim($_POST['error_reporting']),
    ];

    if (empty($newConfig['app_name']) || empty($newConfig['admin_email']) || empty($newConfig['app_url'])) {
        $error = "Please fill in all required fields";
    } else {
        $configContent = "<?php\n";
        $configContent .= "require_once __DIR__.\"/../config/db.php\";\n";
        $configContent .= "\$config = [\n";
        foreach ($newConfig as $key => $value) {
            $configContent .= "    '$key' => '" . addslashes($value) . "',\n";
        }
        $configContent .= "];\n";
        $configContent .= "?>";

        if (file_put_contents($configFile, $configContent)) {
            $success = true;
            $currentConfig = $newConfig;
        } else {
            $error = "Failed to save settings. Check file permissions.";
        }
    }
}
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-cog"></i> Application Settings</h4>
                </div>
                <div class="card-body">
                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> Settings saved successfully!
                        </div>
                    <?php endif; ?>

                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Application Name *</label>
                            <input type="text" class="form-control" name="app_name" 
                                   value="<?= htmlspecialchars($currentConfig['app_name']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Direction *</label>
                            <select class="form-select" name="dir" required>
                                <option value="ltr" <?= $currentConfig['dir'] === 'ltr' ? 'selected' : '' ?>>Left to Right (LTR)</option>
                                <option value="rtl" <?= $currentConfig['dir'] === 'rtl' ? 'selected' : '' ?>>Right to Left (RTL)</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Language *</label>
                            <select class="form-select" name="lang" required>
                                <option value="en" <?= $currentConfig['lang'] === 'en' ? 'selected' : '' ?>>English</option>
                                <option value="ar" <?= $currentConfig['lang'] === 'ar' ? 'selected' : '' ?>>Arabic</option>
                                <option value="fr" <?= $currentConfig['lang'] === 'fr' ? 'selected' : '' ?>>French</option>
                                <option value="es" <?= $currentConfig['lang'] === 'es' ? 'selected' : '' ?>>Spanish</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Display Errors *</label>
                            <select class="form-select" name="display_errors" required>
                                <option value="1" <?= $currentConfig['display_errors'] === '1' ? 'selected' : '' ?>>On</option>
                                <option value="0" <?= $currentConfig['display_errors'] === '0' ? 'selected' : '' ?>>Off</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Error Reporting *</label>
                            <select class="form-select" name="error_reporting" required>
                                <option value="E_ALL" <?= $currentConfig['error_reporting'] === 'E_ALL' ? 'selected' : '' ?>>Report All</option>
                                <option value="E_ALL & ~E_NOTICE" <?= $currentConfig['error_reporting'] === 'E_ALL & ~E_NOTICE' ? 'selected' : '' ?>>Report All Except NOTICE</option>
                                <option value="0" <?= $currentConfig['error_reporting'] === '0' ? 'selected' : '' ?>>Off</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Admin Email *</label>
                            <input type="email" class="form-control" name="admin_email" 
                                   value="<?= htmlspecialchars($currentConfig['admin_email']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Application URL *</label>
                            <input type="url" class="form-control" name="app_url" 
                                   value="<?= htmlspecialchars($currentConfig['app_url']) ?>" 
                                   placeholder="http://example.com/php/" required>
                            <div class="form-text">Include trailing slash at the end</div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Save Settings
                            </button>
                            <a href="index.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Dashboard
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-info-circle"></i> Current Configuration</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <th>Setting</th>
                                <th>Value</th>
                            </tr>
                            <?php foreach ($currentConfig as $key => $value): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars(ucwords(str_replace('_', ' ', $key))) ?></strong></td>
                                <td><?= htmlspecialchars($value) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'template/footer.php'; ?>