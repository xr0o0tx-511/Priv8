<?php
require_once 'template/header.php';
$name = $email = $role = $password = $new_password = $confirm_password = "";
$NameError = $EmailError = $RoleError = $PasswordError = $ConfirmPasswordError = "";

if ($_SESSION['role'] !== 'admin') {
    echo "Only Admin Can Access this page";
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete']; 
    $stmt = $mysqli->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: users.php");
    exit;
}

$users = $mysqli->query("SELECT * FROM users")->fetch_all(MYSQLI_ASSOC);

if (isset($_GET['update'])) {
    $id = (int) $_GET['update'];
    $stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!empty($_POST['name'])) {
            $new_name = trim(FilterString($_POST['name']));
            $stmt = $mysqli->prepare("SELECT * FROM users WHERE name = ? AND id != ?");
            $stmt->bind_param("si", $new_name, $id);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) { 
                $NameError = "Username already taken";
            } else {
                $stmt = $mysqli->prepare("UPDATE users SET name = ? WHERE id = ?");
                $stmt->bind_param("si", $new_name, $id);
                $stmt->execute();
            }
            $stmt->close();
        }

        if (!empty($_POST['email'])) {
            $new_email = trim(FilterString($_POST['email']));
            $stmt = $mysqli->prepare("SELECT * FROM users WHERE email = ? AND id != ?");
            $stmt->bind_param("si", $new_email, $id);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) { 
                $EmailError = "Email already taken";
            } else {
                $stmt = $mysqli->prepare("UPDATE users SET email = ? WHERE id = ?");
                $stmt->bind_param("si", $new_email, $id);
                $stmt->execute();
            }
            $stmt->close();
        }

        if (!empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
            $new_password = trim(FilterString($_POST['new_password']));
            $confirm_password = trim(FilterString($_POST['confirm_password']));
            if ($new_password !== $confirm_password) {
                $ConfirmPasswordError = "Passwords do not match";
            } else {
                $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $mysqli->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->bind_param("si", $hashed_new_password, $id);
                $stmt->execute();
                $stmt->close();
            }
        }

        if (isset($_POST['role']) && ($_POST['role'] === 'admin' || $_POST['role'] === 'user')) {
            $new_role = trim(FilterString($_POST['role']));
            $stmt = $mysqli->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->bind_param("si", $new_role, $id);
            $stmt->execute();
            $stmt->close();
        }

        header("Location: users.php?update={$id}");
        exit;
    }
}

if (isset($_GET['add'])) {
    if (isset($_POST['name'], $_POST['email'], $_POST['role'], $_POST['password'], $_POST['confirm_password'])) {
        $name = trim(FilterString($_POST['name']));
        $email = trim(FilterString($_POST['email']));
        $role = trim(FilterString($_POST['role']));
        $password = trim(FilterString($_POST['password']));
        $confirm_password = trim(FilterString($_POST['confirm_password']));

        $stmt = $mysqli->prepare("SELECT * FROM users WHERE name = ?");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) { 
            $NameError = "Username already taken";
        } else {
            $stmt = $mysqli->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) { 
                $EmailError = "Email already taken";
            } else if ($password !== $confirm_password) {
                $ConfirmPasswordError = "Passwords do not match";
            } else if ($role !== 'admin' && $role !== 'user') {
                $RoleError = "Select a valid role";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $mysqli->prepare("INSERT INTO users (name,email,role,password) VALUES (?,?,?,?)");
                $stmt->bind_param("ssss", $name, $email, $role, $hashed_password);
                if ($stmt->execute()) {
                    header("Location: users.php?success=1");
                    exit;
                } else {
                    $PasswordError = "Failed to add user";
                }
            }
        }
        $stmt->close();
    }
}
?>

<?php if(!isset($_GET['view']) && !isset($_GET['update']) && !isset($_GET['add'])) { ?>
<h2>Users</h2>
<div class="mb-3">
    <a href="users.php?add=1" class="btn btn-success">Add New User</a>
</div>
<div class="table-responsive">
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($users as $user){ ?>
            <tr>
                <td><?= $user['id']; ?></td>
                <td><?= htmlspecialchars($user['name']); ?></td>
                <td><?= htmlspecialchars($user['email']); ?></td>
                <td><?= htmlspecialchars($user['role']); ?></td>
                <td>
                    <a href="?view=<?= $user['id']; ?>" class="btn btn-sm btn-primary">View</a>
                    <a href="?delete=<?= $user['id']; ?>" onclick="return confirm('Delete this user?')" class="btn btn-sm btn-danger">Delete</a>
                    <a href="?update=<?= $user['id']?>" class="btn btn-primary">Update</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php } ?>

<?php if(isset($_GET['view'])) { 
    $id = (int) $_GET['view'];
    $stmt = $mysqli->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($user) { ?>
<div class="container mt-4">
    <a href="users.php" class="btn btn-secondary mb-3">← Back to Users</a>
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Username: <?= htmlspecialchars($user['name']); ?></h4>
        </div>
        <div class="card-body">
            <p><strong>Email:</strong> <?= htmlspecialchars($user['email']); ?></p>
            <p><strong>Role:</strong> <?= htmlspecialchars($user['role']); ?></p>
        </div>
        <div class="card-footer">
            <a href="mailto:<?= htmlspecialchars($user['email']); ?>" class="btn btn-primary">Email User</a>
            <a href="?delete=<?= $user['id']; ?>" class="btn btn-danger" onclick="return confirm('Delete this user?')">Delete</a>
            <a href="?update=<?= $user['id']?>" class="btn btn-primary">Update</a>
        </div>
    </div>
</div>
<?php } } ?>

<?php if(isset($_GET['update'])) { ?>
<div class="container mt-5">
    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-header text-center">
            <h3>User Profile</h3>
        </div>
        <div class="card-body">
            <form action="users.php?update=<?= $user['id']; ?>" method="POST">
                <div class="mb-3">
                    <label class="form-label" for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($user['name']); ?>" required>
                    <span class="text-danger"><?= $NameError ?></span>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>
                    <span class="text-danger"><?= $EmailError ?></span>
                </div>
                <div class="mb-3">
                    <label for="new_password" class="form-label">New Password</label>
                    <input type="password" class="form-control" id="new_password" name="new_password" value="<?= htmlspecialchars($new_password) ?>">
                    <span class="text-danger"><?= $PasswordError ?></span>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" value="<?= htmlspecialchars($confirm_password) ?>">
                    <span class="text-danger"><?= $ConfirmPasswordError ?></span>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Role</label>
                    <select id="role" name="role" class="form-select">
                        <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                        <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>User</option>
                    </select>
                    <span class="text-danger"><?= $RoleError ?></span>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php } ?>

<?php if(isset($_GET['add'])) { ?>
<?php if (isset($_GET['success'])): ?>
<div class="alert alert-success">User added successfully!</div>
<?php endif; ?>
<div class="container mt-5">
    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-header text-center">
            <h3>Add User</h3>
        </div>
        <div class="card-body">
            <form action="users.php?add=1" method="POST">
                <div class="mb-3">
                    <label class="form-label" for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($name); ?>" required>
                    <span class="text-danger"><?= $NameError ?></span>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email); ?>" required>
                    <span class="text-danger"><?= $EmailError ?></span>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" value="<?= htmlspecialchars($password); ?>" required>
                    <span class="text-danger"><?= $PasswordError ?></span>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" value="<?= htmlspecialchars($confirm_password); ?>" required>
                    <span class="text-danger"><?= $ConfirmPasswordError ?></span>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Role</label>
                    <select id="role" name="role" class="form-select">
                        <option value="">-- Select a User Role --</option>
                        <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
                        <option value="user" <?= $role === 'user' ? 'selected' : '' ?>>User</option>
                    </select>
                    <span class="text-danger"><?= $RoleError ?></span>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Add User</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php } ?>

<?php require_once 'template/footer.php'; ?>
