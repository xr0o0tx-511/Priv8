<?php 
$title = "Profile Page";
require_once 'template/header.php'; 
require 'classes/Service.php';
require 'classes/Product.php';

$new_name = $new_email = $current_password = $new_password = $confirm_password = "";
$NameError = $EmailError = $CurrentPasswordError = $NewPasswordError = $ConfirmPasswordError = "";

if(!isset($_SESSION['id']) || !isset($_SESSION['name']) || !isset($_SESSION['role'])){
    echo "You're Not Logged";
    die();
}

if(isset($_POST['name']) && $_SESSION['name'] !== $_POST['name'] && !empty($_POST['name'])){
    $new_name = trim(FilterString($_POST['name']));
    $stmt = $mysqli->prepare("SELECT * FROM users WHERE name = ?");
    $stmt->bind_param("s", $new_name);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows > 0){ 
        $NameError = "Username already taken. Try another one";
    } else {
        $stmt = $mysqli->prepare("UPDATE users SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $new_name, $_SESSION['id']);
        if($stmt->execute()){
            $_SESSION['name'] = $new_name;
            header("Location: /php/profile.php");
            exit();
        } else {
            $NameError = "Failed to update name, try again.";
        }
    }
    $stmt->close();
}

if(isset($_POST['email']) && $_SESSION['email'] !== $_POST['email'] && !empty($_POST['email'])){
    $new_email = trim(FilterString($_POST['email']));
    $stmt = $mysqli->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $new_email);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows > 0){ 
        $EmailError = "Email already taken. Try another one";
    } else {
        $stmt = $mysqli->prepare("UPDATE users SET email = ? WHERE id = ?");
        $stmt->bind_param("si", $new_email, $_SESSION['id']);
        if($stmt->execute()){
            $_SESSION['email'] = $new_email;
            header("Location: /php/profile.php");
            exit();
        } else {
            $EmailError = "Failed to update email, try again.";
        }
    }
    $stmt->close();
}

if(!empty($_POST['current_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])){
    $current_password = trim(FilterString($_POST['current_password']));
    $new_password = trim(FilterString($_POST['new_password']));
    $confirm_password = trim(FilterString($_POST['confirm_password']));

    $stmt = $mysqli->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    if(!password_verify($current_password, $data['password'])){
        $CurrentPasswordError = "Current Password is incorrect";
    } elseif($new_password !== $confirm_password){
        $ConfirmPasswordError = "New passwords do not match";
    } else {
        $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $mysqli->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed_new_password, $_SESSION['id']);
        if($stmt->execute()){
            header("Location: /php/profile.php");
            exit();
        } else {
            $NewPasswordError = "Failed to update password, try again.";
        }
        $stmt->close();
    }
}
?>

<div class="container mt-5">
    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-header text-center">
            <h3>User Profile</h3>
        </div>
        <div class="card-body">
            <form action="profile.php" method="POST">
                <div class="mb-3">
                    <label class="form-label" for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($_SESSION['name']); ?>" required>
                    <span class="text-danger"><?php echo $NameError?></span>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" required>
                    <span class="text-danger"><?php echo $EmailError?></span>
                </div>
                <div class="mb-3">
                    <label for="current_password" class="form-label">Current Password</label>
                    <input type="password" class="form-control" value="<?php echo htmlspecialchars($current_password);?>" id="current_password" name="current_password" >
                    <span class="text-danger"><?php echo $CurrentPasswordError?></span>
                </div>
                <div class="mb-3">
                    <label for="new_password" class="form-label"> New Password</label>
                    <input type="password" class="form-control" value="<?php echo htmlspecialchars($new_password)?>" id="new_password" name="new_password" >
                    <span class="text-danger"><?php echo $NewPasswordError?></span>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <input type="confirm_password" class="form-control" value="<?php echo htmlspecialchars($confirm_password)?>" id="confirm_password" name="confirm_password" >
                    <span class="text-danger"><?php echo $ConfirmPasswordError?></span>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="role">Role</label>
                    <input type="text" class="form-control" id="role" value="<?php echo htmlspecialchars($_SESSION['role']); ?>" readonly>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once 'template/footer.php'; ?>