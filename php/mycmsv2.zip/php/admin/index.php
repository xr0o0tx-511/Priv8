<?php
require_once 'template/header.php';


?>
<main>
    <h2>Welcome, Admin</h2>
    <p>This is your dashboard.</p>
</main>


<?php require_once 'template/footer.php'; ?>