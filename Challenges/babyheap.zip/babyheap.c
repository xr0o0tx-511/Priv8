#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char *table[16];
int idx = 0;

void alloc();
void delete();
void view();
void edit();
unsigned long size;
void alloc(){
    printf("Index: ");
    scanf("%d",&idx);
    printf("size: ");
    scanf("%ld",&size);
        if(size <= 120){
            table[idx] = (char *)malloc(size);
            printf("Data: ");
            getchar();
            read(0,table[idx],size+0x1);
        }
        else{
            printf("The Size Most Be less or equal to 0x78\n");
            }
}

void delete(){  
    printf("Index: ");
    scanf("%d",&idx);
    if(table[idx]){
    free(table[idx]);
    table[idx] = NULL;
    }else{
        printf("NO Double Free\n");
    }

}

void edit(){
    printf("Index: ");
    scanf("%d",&idx);
    if(table[idx]){
        printf("Data: ");
        getchar();
        read(0,table[idx],size+0x1);
    }else{
        printf("No UAF\n");
    }
}

void view(){
    printf("Index: ");
    scanf("%d",&idx);
    write(1,table[idx],sizeof(table[idx]));
}

int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    while(1){
    char choice[5];
    int cho;
    printf("\n1- Alloc\n2- Edit\n3- Free\n4- View\n> ");
    read(0,choice,sizeof(choice));
    cho = atoi(choice);
    switch (cho){
        case 1:
            alloc();
            break;
        case 2:
            edit();
            break;
        case 3:
            delete();
            break;
        case 4:
            view();
            break;

        default:
            printf("Invaild Choice\n");

    }

}}