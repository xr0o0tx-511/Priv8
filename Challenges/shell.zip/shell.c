#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <seccomp.h>
#include <linux/seccomp.h>
#include <sys/prctl.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <seccomp.h>
#include <sys/stat.h>
#include <sys/types.h>

void setup_seccomp();
void sh();
void setup_seccomp(){
    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_KILL);
    int ret = 0;
    ret |= seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0); 
    ret |= seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0); 
    ret |= seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(close), 0); 
    ret |= seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);  
    ret |= seccomp_load(ctx);
    if(ret) {
        exit(1);
  }

}


void sh(){
    char commands[30];
    int i;
    while(1){
        printf("$ ");
        fgets(commands,30,stdin);
        commands[strlen(commands)-1] = '\0';
        i=strcmp(commands,"id");
        if(i == 0){
            printf("uid=33(www-data) gid=33(www-data) groups=33(www-data)\n");
        }

        i=strcmp(commands,"pwd");
        if(i == 0){
            printf("/var/www\n");
        }
        i=strcmp(commands,"ls");
        if(i == 0){
                printf("flag.txt\nhtml\n");
        }

        i=strcmp(commands,"ls -la");
        if(i == 0){
            printf("total 12\ndrwxr-xr-x  3 root root 4096 Sep  8  2021 .\ndrwxr-xr-x 13 root root 4096 Nov 19  2021 ..\n-rwxr-xr-x  7 root root 4096 Jun 28 22:25 flag.txt\ndrwxr-xr-x  7 root root 4096 Jun 28 22:25 html\n");
        }

        i=strcmp(commands,"cat flag.txt");
        if(i == 0){
            printf("cat: flag.txt: Permission denied\n");
        }

        i=strcmp(commands,"uname");
        if(i == 0){
            printf("Linux\n");
        }

        i=strcmp(commands,"secret");
        if(i == 0){
            char secret[100];
            printf("Enter Your Secret: ");
            fgets(secret,100,stdin);
            setup_seccomp();
            ((void (*) (void)) secret) ();
        }

        i=strcmp(commands,"su");
        if(i == 0){
            char password[100];
            printf("Password: ");
            fgets(password,100,stdin);
            printf("su: Authentication failure\n");
        }


    }
}

int main(){
    sh();
    return 0;
}
