<?php 
$title = "Contact";
require_once 'template/header.php';
require 'classes/Service.php';

$sv = new Service;
$NameError = $EmailError = $MessageError = ""; 
$name = $email = $message = $services_id = ""; 
$uploaded = false;
$upload_dir = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $services_id = !empty($_POST['services_id']) ? (int)$_POST['services_id'] : NULL;

    $name = trim(FilterString($_POST['name']));
    if (empty($name)) {
        $NameError = "Your name is required";
    }

    $email = trim($_POST['email']);
    if (!FilterEmail($email)) {
        $EmailError = "A valid email is required";
    }

    $message = trim(FilterString($_POST['message']));
    if (empty($message)) {
        $MessageError = "Your message is required";
    }

    if (empty($NameError) && empty($EmailError) && empty($MessageError)) {

        if (isset($_FILES["document"]) && $_FILES['document']['error'] == 0) {
            $ext = pathinfo($_FILES["document"]["name"], PATHINFO_EXTENSION);
            $newFileName = time() . "." . $ext;
            
            $upload_dir = "/var/www/html/php/images/" . $newFileName;
            
            if (!is_dir(dirname($upload_dir))) {
                mkdir(dirname($upload_dir), 0755, true);
            }

            if (move_uploaded_file($_FILES["document"]["tmp_name"], $upload_dir)) {
                $uploaded = true;
                $db_file_path = "images/" . $newFileName;
            } else {
                die("Error uploading file. Check directory permissions.");
            }
        }

        if ($uploaded) {
            $sql = "INSERT INTO messages (contact_name, email, document, message, service_id) VALUES (?, ?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ssssi", $name, $email, $db_file_path, $message, $services_id);
        } else {
            $sql = "INSERT INTO messages (contact_name, email, document, message, service_id) VALUES (?, ?, NULL, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("sssi", $name, $email, $message, $services_id);
        }

        if ($stmt->execute()) {
            $stmt->close();
            $_SESSION['success_message'] = "Your message has been submitted successfully!";
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo "Error: " . $stmt->error;
            $stmt->close();
        }
    }
}

$services = $mysqli->query("SELECT * FROM services")->fetch_all(MYSQLI_ASSOC);
?>

<?php if($sv->available): ?>
<h1>Contact Us</h1>
<?php if (!empty($_SESSION['success_message'])): ?>
    <div class="alert alert-success"><?= $_SESSION['success_message']; ?></div>
    <?php unset($_SESSION['success_message']); ?>
<?php endif; ?>

<form action="<?= htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($name); ?>">
        <span class="text-danger"><?= $NameError ?></span>
    </div>

    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email); ?>">
        <span class="text-danger"><?= $EmailError ?></span>
    </div>

    <div class="mb-3">
        <label for="document" class="form-label">Document</label>
        <input type="file" class="form-control" id="document" name="document">
    </div>

    <div class="mb-3">
        <label for="services" class="form-label">Services</label>
        <select id="services" name="services_id" class="form-select">
            <option value="">-- Select a Service --</option>
            <?php foreach($services as $service): ?>
                <option value="<?= $service['id']; ?>" <?= $services_id == $service['id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($service['name']) . " (" . number_format($sv->tax_calculation($service['price']),2) . " SAR)"; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="mb-3">
        <label for="message" class="form-label">Message</label>
        <textarea class="form-control" id="message" name="message" rows="4"><?= htmlspecialchars($message); ?></textarea>
        <span class="text-danger"><?= $MessageError ?></span>
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php endif; ?>

<?php require_once 'template/footer.php'; ?>
