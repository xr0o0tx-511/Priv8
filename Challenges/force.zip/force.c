#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void add();
void advice();
void hint();

void advice(){
    printf("The Advice is Follow Your Dreams\n");
}

void hint(){
    char *ptr;
    ptr = (char *)malloc(0x88);
    printf("");
    printf("Heap: %p\nprintf: %p\n",ptr,printf);
    free(ptr);
}

void add(){
    char *table[5];
    table[0] = NULL;
    table[1] = NULL;
    table[2] = NULL;
    table[3] = NULL;
    table[4] = NULL;
    unsigned long size;
    for(int i = 0;i < 9;i++){
                char buf[50];
                printf("Enter size of Dream: ");
                scanf("%ld",&size);
                table[i] = (char *)malloc(size);
                printf("Enter Your Dream: ");
                read(0,table[i++],size+8);
                printf("Maybe One Day your Dream will come True :)\n");
                break;
}}

int main(){
    setvbuf(stdout,(char *)0x0,2,0);
    int choice;
    while(1){
        printf("\n1- Advice\n2- Write Your Dreams\n\n> ");
        scanf("%d",&choice);
        switch (choice){
            case 1:
                    advice();
                    break;
            case 2:
                    add();
                    break;
            case 31337:
                    hint();
                    break;
                    
            default:
                printf("Invaild Choice :(\n");

        }
    }
}
