
<footer>
    &copy; 2025 My Admin Panel
</footer>

</body>
</html>
