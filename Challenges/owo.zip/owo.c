//gcc owo.c -o owo -Wl,-z,relro -z now -no-pie -fstack-protector
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define GREEN   "\x1b[32m"
#define def     "\033[0m"
#define RED     "\x1b[31m"
void login();
int chat();
int get_input(){
    char message[50];
    gets(&message);
    return 0;
}

struct users{
    char name[9];
    char password[100];
    char email[50];
    char priv[7];
};

char users[5][10] = {"root","rick","daryl","negin","xr0o0tx"};
char orguser[] = "xr0o0tx";
int orgpass = 4919;

void login(){
    char username[20];
    long int password;
    int i;
    printf("Enter Username: ");
    fgets(username,20,stdin);
    username[strlen(username)-1] = '\0';
    i=strcmp(username,"xr0o0tx");
    if(i == 0){
        int b;
        printf("Enter Password: ");
        scanf("%d",&password);
        b=password^0x11;
        if(b == orgpass){
            printf(GREEN "[+] Login is Successful\n" def);
            printf("[*] Attempting to Connect to Server\n");
            chat();    
        }
        else{
            printf(RED "Password is invaild\n" def);
            exit(0);
        }
    }
    else {
            printf(RED "Username is invaild\n" def);
            exit(0);
    }
}

int chat(){
    struct users root = {"root","03d92a9118d436d505017dc5737cd583","root@local.local","True"};
    struct users rick = {"rick","10acdff6de04d32f456ae673ab4d11a3","rick@local.local","False"};
    struct users daryl = {"daryl","7a3473da9cc7a7b6212ff35fa5260ba8","daryl@local.local","False"};
    struct users negin = {"negin","bd3a73be332361ce94cdbed5c59a02e9","negin@local.local","True"};
    struct users xr0o0tx = {"xr0o0tx","76b7a3a5cf67f3c4fcde3a8b39dab7be","xr0o0tx@local.local","False"};

        char commands[30];
        int i;
        int b;
        printf(GREEN "[+] Successfully Connecting To Server\n" def);
        printf("Enter help to see commands\n");
    while(1){
        printf("xr0o0tx: ");
        fgets(commands,30,stdin);
        commands[strlen(commands)-1] = '\0';
        i=strcmp(commands,"help");
        if(i == 0)
        {
            printf("All commmands:\nusers\nsend\ninfo\nexit\n");
        }

        i=strcmp(commands,"users");
        if(i == 0){
            int j;
            for (j = 0;i < 5;i++)
            {
                printf("%s\n",users[i]);
            }
        }

        i=strcmp(commands,"info");
        if(i == 0)
        {
            printf("Error!\n Usage:  info username\n");
        }
            i=strcmp(commands,"info root");
            if(i == 0)
            {
                printf("user: %s\nPassword: %s\nemail: %s\nadmin: %s\n",root.name,root.password,root.email,root.priv);
            }
             i=strcmp(commands,"info rick");
            if(i == 0)
            {
                printf("user: %s\nPassword: %s\nemail: %s\nadmin: %s\n",rick.name,rick.password,rick.email,rick.priv);
            }
            i=strcmp(commands,"info daryl");
            if(i == 0)
            {
                printf("user: %s\nPassword: %s\nemail: %s\nadmin: %s\n",daryl.name,daryl.password,daryl.email,daryl.priv);
            }
            i=strcmp(commands,"info negin");
            if(i == 0)
            {
               printf("user: %s\nPassword: %s\nemail: %s\nadmin: %s\n",negin.name,negin.password,negin.email,negin.priv);
            }

            i=strcmp(commands,"info xr0o0tx");
            if(i == 0)
            {
                printf("user: %s\nPassword: %s\nemail: %s\nadmin: %s\n",xr0o0tx.name,xr0o0tx.password,xr0o0tx.email,xr0o0tx.priv);
            }
        
        i=strcmp(commands,"send");
        if(i == 0)
        {
            printf("Error!\n Usage:  send username\n");
        }

            i=strcmp(commands,"send root");
            if(i == 0)
            {
                char message[30];
                printf("What is Your Message: ");
                read(0,message,30);
                printf(GREEN "Message Sent Successfully\n" def);
            }
            i=strcmp(commands,"send rick");
            if(i == 0)
            {
                char message[480];
                printf("What is Your Message: ");
                read(0,message,480);
                write(1,message,0x144);
                printf(GREEN "Message Sent Successfully\n" def);
            }
            i=strcmp(commands,"send daryl");
            if(i == 0)
            {
                char message[30];
                printf("What is Your Message: ");
                read(0,message,30);
                printf(GREEN "Message Sent Successfully\n" def);
            }
            i=strcmp(commands,"send negin");
            if(i == 0)
            {
                char message[50];
                printf("What is Your Message: ");
                get_input();
                puts(GREEN "Message Sent Successfully\n" def);
            }
            i=strcmp(commands,"send xr0o0tx");
            if(i == 0)
            {
                printf(RED "You cannot send a message to yourself\n" def);
            }
        i=strcmp(commands,"exit");
        if(i == 0)
        {
            printf("G00D Bye\n");
            exit(0);
        }
    } 
    return 0;
}


int main(){
    setvbuf(stdout,(char *)0x2,0,0);
    login();
    return 0;
}