#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void win();
void hint();
void msg();
void menu();


void msg(){
	char msg[50];
	printf("Address Of Developer: %p\n",&msg);
	printf("Enter Your Message: \n");
	read(0,msg,70);

}

void hint(){
        puts("You Don`t Need a Hint it`s Easy :)\n");
        menu();
}


void menu(){
	printf("\n");
        char choice;
        printf("1- Hint\n");
        printf("2- Write Message For Developer\n");
        printf("3- Exit\n\n");
        printf("> ");
        scanf("%c",&choice);
        getchar();
        switch (choice) {
                case '1':
                        hint();
                        break;
                case '2':
                        msg();
                        break;
                case '3':
                        printf("Good By *_*");
                        exit(0);
                        break;
                default:
                        printf("Invaild Choice :(");
                        break;
        }
}


int main(){
	menu();
	return 0;
}
