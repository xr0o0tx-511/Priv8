#!/bin/bash
cd /home/ctf && ./bank
