<?php
require_once __DIR__."/../config/db.php";
$config = [
    'app_name' => 'Service App',
    'dir' => 'ltr',
    'lang' => 'en',
    'admin_email' => 'admin@admin.local',
    'app_url' => 'http://127.0.0.1/php/',
    'display_errors' => '1',
    'error_reporting' => 'E_ALL',
];
?>