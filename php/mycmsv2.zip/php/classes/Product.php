<?php
class Product {
    public static function all(): array{
        return[
            ['name' => 'Computer','price' => 1000],
            ['name' => 'Keyboard','price' => 30],
            ['name' => 'Mouse','price' => 5]
        ];
    }
}