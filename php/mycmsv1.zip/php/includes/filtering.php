<?php 
require_once __DIR__."/../config/app.php";
require_once __DIR__."/../config/db.php";

function FilterString($data){
    $clean_data = htmlspecialchars($data);
    if(empty($data)){
        return false;
    }else{
        return $clean_data;
    }
}

function FilterEmail($data){
    $clean_email = filter_var(trim($data),FILTER_SANITIZE_EMAIL);
    if(filter_var($clean_email,FILTER_VALIDATE_EMAIL)){
        return $clean_email;
    }else{
        return false;
    }
}


?>