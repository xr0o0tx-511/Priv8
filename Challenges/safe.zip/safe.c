#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char *table[2];

void alloc();
void edit();
void delete();
void check();

int idx = 0;
unsigned long size;
char priv[] = "guest\x00";

void alloc(){    
    printf("Index: ");
    scanf("%d",&idx);
    if(idx <= 2){
        printf("size: ");
        scanf("%ld",&size);
        table[idx] = (char *)malloc(size);
    }else{
        printf("Erorr The Index is greater than 2");
    }
}

void delete(){  
    printf("Index: ");
    scanf("%d",&idx);
    if(idx >= 2){
        printf("Invaild Index\n");
    }
    else if(table[idx]){
        free(table[idx]);
        table[idx] = NULL;
    }else{
        printf("This Chunk is Already Freed\n");
    }
}

void edit(){
    printf("Index: ");
    scanf("%d",&idx);
    if(idx >= 2){
        printf("Invaild Index\n");
    }
    else{
        printf("Data: ");
        getchar();
        fgets(table[idx],size+8,stdin);
    }
}

void check(){
    int value;
    value=strcmp(priv,"root\x00");
    if(value == 0){
        system("/bin/sh\x00");
    }else{
        printf("Error You are not root\n");
    }
}

int main(){
    setvbuf(stdout, 0, 2, 0);
	setvbuf(stdin, 0, 2, 0);
    while(1){
    int choice;
    printf("\n1- Alloc\n2- Edit\n3- Free\n\n> ");
    scanf("%d",&choice);
    switch (choice){
        case 1:
            alloc();
            break;
        case 2:
            edit();
            break;
        case 3:
            delete();
            break;
        case 4:
            check();
            break;
        default:
            printf("Invaild Choice\n");

    }

}}