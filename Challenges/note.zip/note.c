#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int idx = 9;
char *table[10];

void add();
void edit();
void rem();
void show();
void menu();

int main() {
        setvbuf(stdout, 0, 2, 0);
        setvbuf(stdin, 0, 2, 0);
        setvbuf(stderr, 0, 2, 0);
	while(1) {
        	menu();
	}
        return 0;

}


void menu(){
        int choice;
	printf("\n");
        printf("1- Add Note\n");
        printf("2- Edit Note\n");
        printf("3- Delete Note\n");
        printf("4- View Note\n");
        printf("5- Exit\n\n");
        printf("> ");
        scanf("%d",&choice);
        switch (choice) {
                case 1:
                        add();
                        break;
                case 2:
                        edit();
                        break;
                case 3:
                        rem();
                        break;
                case 4:
                        show();
                        break;
                case 5:
			printf("G00d Bye\n");
                        exit(0);
                        break;
                default:
                        printf("invaild Choice\n");
}
}


void add()
{
	char buf[10];
	printf("Enter index: ");
	read(0,buf,10);
	idx = atoi(buf);
	if(idx >= 0 && idx <= 9){
			if(table[idx]) {
				puts("The Index is usage\n");
			}

			else {
				size_t size = 0;
				char buf[8];
				printf("Enter Size: ");
				read(0,buf,8);
				size = atoi(buf);
				if(size >= 0 && size <= 1024){
					table[idx] = (char *)malloc(size);
					printf("Enter Data: ");
					read(0,table[idx],50);
				}
				else {
					printf("Malloc Error\\nn");
					}
		}
}
}

void edit(){
	char buf[10];
	printf("Enter index: ");
        read(0,buf,10);
	idx = atoi(buf);
        if(idx >= 0 && idx <= 9){
		if(!table[idx]){
                        printf("The index is not usage\n");
                }
		else{
			printf("Enter Data: ");
                	read(0,table[idx],40);
			}
	}
	else {
		printf("Invaild index\n");
		}
}

void rem(){
	printf("Enter index: ");
        scanf("%d",&idx);
        if(idx >= 0 && idx <= 9){
		if(!table[idx]){
			printf("The index is not usage\n");
		}
		else{
			free(table[idx]);
		}
	}
	else{
		printf("Invaild index\n");
	}
}

void show(){
	printf("Enter index: ");
        scanf("%d",&idx);
        if(idx >= 0 && idx <= 9){
		if(!table[idx]){
                        printf("The index is Empty\n");
                	}
		else {
			printf("%s",table[idx]);
			}
	}
	else {
		printf("Invaild index\n");
        }
}

