<?php
require_once 'template/header.php';

$name = $days = $price = "";
$NameError = $DaysError = $PriceError = "";

if ($_SESSION['role'] !== 'admin') {
    echo "Only Admin Can Access this page";
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $mysqli->prepare("DELETE FROM services WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: services.php");
    exit;
}

$services = $mysqli->query("SELECT * FROM services")->fetch_all(MYSQLI_ASSOC);

if (isset($_GET['update'])) {
    $id = (int) $_GET['update'];
    $stmt = $mysqli->prepare("SELECT * FROM services WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $service = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $new_name = trim(FilterString($_POST['name']));
        $new_days = trim(FilterString($_POST['days']));
        $new_price = trim(FilterString($_POST['price']));

        $stmt = $mysqli->prepare("SELECT * FROM services WHERE name = ? AND id != ?");
        $stmt->bind_param("si", $new_name, $id);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) { 
            $NameError = "Name already taken";
        } else {
            $stmt = $mysqli->prepare("UPDATE services SET name=?, days=?, price=? WHERE id=?");
            $stmt->bind_param("ssdi", $new_name, $new_days, $new_price, $id);
            $stmt->execute();
            $stmt->close();
        }

        header("Location: services.php?update={$id}");
        exit;
    }
}

if (isset($_GET['add'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim(FilterString($_POST['name']));
        $days = trim(FilterString($_POST['days']));
        $price = trim(FilterString($_POST['price']));

        $stmt = $mysqli->prepare("SELECT * FROM services WHERE name = ?");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $NameError = "Name already taken";
        } else {
            $stmt = $mysqli->prepare("INSERT INTO services (name, days, price) VALUES (?, ?, ?)");
            $stmt->bind_param("ssd", $name, $days, $price);
            if ($stmt->execute()) {
                header("Location: services.php?success=1");
                exit;
            } else {
                $PriceError = "Failed to add service";
            }
        }
        $stmt->close();
    }
}
?>

<?php if(!isset($_GET['update']) && !isset($_GET['add'])): ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Services Management</h2>
        <a href="services.php?add=1" class="btn btn-success">
            <i class="fas fa-plus"></i> Add New Service
        </a>
    </div>

    <?php if(isset($_GET['success'])): ?>
        <div class="alert alert-success">Service added successfully!</div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Days</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($services as $service): ?>
                        <tr>
                            <td><?= $service['id']; ?></td>
                            <td><?= htmlspecialchars($service['name']); ?></td>
                            <td><?= htmlspecialchars($service['days']); ?></td>
                            <td>$<?= number_format($service['price'], 2); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="?update=<?= $service['id']; ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <a href="?delete=<?= $service['id']; ?>" onclick="return confirm('Are you sure you want to delete this service?')" class="btn btn-danger btn-sm">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(isset($_GET['update'])): ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Update Service</h4>
                </div>
                <div class="card-body">
                    <form action="services.php?update=<?= $service['id']; ?>" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($service['name']); ?>" required>
                            <span class="text-danger"><?= $NameError ?></span>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Days</label>
                            <input type="text" class="form-control" name="days" value="<?= htmlspecialchars($service['days']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" step="0.01" class="form-control" name="price" value="<?= htmlspecialchars($service['price']); ?>" required>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Update Service</button>
                            <a href="services.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(isset($_GET['add'])): ?>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0">Add New Service</h4>
                </div>
                <div class="card-body">
                    <form action="services.php?add=1" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($name); ?>" required>
                            <span class="text-danger"><?= $NameError ?></span>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Days</label>
                            <input type="text" class="form-control" name="days" value="<?= htmlspecialchars($days); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" step="0.01" class="form-control" name="price" value="<?= htmlspecialchars($price); ?>" required>
                            <span class="text-danger"><?= $PriceError ?></span>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success">Add Service</button>
                            <a href="services.php" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once 'template/footer.php'; ?>