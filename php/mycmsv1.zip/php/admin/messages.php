<?php
$title = "Messages";
require_once 'template/header.php';

if (!isset($_SESSION['id'], $_SESSION['name'], $_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "Only Admin Can Access this page";
    die();
}

$messages = $mysqli->query("
    SELECT m.*, s.name as service_name 
    FROM messages m 
    LEFT JOIN services s ON m.service_id = s.id 
    ORDER BY m.id ASC
")->fetch_all(MYSQLI_ASSOC);

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];

    $stmt = $mysqli->prepare("SELECT document FROM messages WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($document);
    $stmt->fetch();
    $stmt->close();

    $delete = $mysqli->prepare("DELETE FROM messages WHERE id = ?");
    $delete->bind_param("i", $id);
    $delete->execute();
    $delete->close();

    if (!empty($document)) {
        $file_path = __DIR__ . '/../' . $document;
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }

    header("Location: messages.php");
    exit;
}

if (!isset($_GET['view'])) { ?>

<h2>Received Messages</h2>
<div class="table-responsive">
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Sender Name</th>
                <th>Sender Email</th>
                <th>Document</th>
                <th>Service</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($messages as $message) { 
            $documentUrl = !empty($message['document']) ? '/php/' . $message['document'] : '';
        ?>
            <tr>
                <td><?= $message['id'] ?></td>
                <td><?= htmlspecialchars($message['contact_name']) ?></td>
                <td><?= htmlspecialchars($message['email']) ?></td>
                <td>
                    <?php if ($documentUrl): ?>
                        <a href="<?= htmlspecialchars($documentUrl) ?>" class="btn btn-success btn-sm" target="_blank">Download</a>
                    <?php endif; ?>
                </td>
                <td><?= htmlspecialchars($message['service_name'] ?? 'None') ?></td>
                <td>
                    <a href="?view=<?= $message['id'] ?>" class="btn btn-sm btn-primary">View</a>
                    <a href="?delete=<?= $message['id'] ?>" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

<?php } else {
    $id = (int)$_GET['view'];
    $stmt = $mysqli->prepare("
        SELECT m.*, s.name as service_name 
        FROM messages m 
        LEFT JOIN services s ON m.service_id = s.id 
        WHERE m.id = ?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $message = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($message) { 
        $documentUrl = !empty($message['document']) ? '/php/' . $message['document'] : '';
    ?>
        <div class="container mt-4">
            <a href="messages.php" class="btn btn-secondary mb-3">← Back to Messages</a>
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4>Message from <?= htmlspecialchars($message['contact_name']) ?></h4>
                </div>
                <div class="card-body">
                    <p><strong>Email:</strong> <?= htmlspecialchars($message['email']) ?></p>
                    <p><strong>Service:</strong> <?= htmlspecialchars($message['service_name'] ?? 'None') ?></p>
                    <?php if ($documentUrl): ?>
                        <p><strong>Document:</strong> 
                            <a href="<?= htmlspecialchars($documentUrl) ?>" class="btn btn-success btn-sm" target="_blank">Download</a>
                        </p>
                    <?php endif; ?>
                    <p><strong>Message:</strong></p>
                    <div class="border p-3 bg-light rounded"><?= nl2br(htmlspecialchars($message['message'])) ?></div>
                </div>
                <div class="card-footer">
                    <a href="mailto:<?= htmlspecialchars($message['email']) ?>" class="btn btn-primary">Reply</a>
                    <a href="?delete=<?= $message['id'] ?>" onclick="return confirm('Are you sure?')" class="btn btn-danger">Delete</a>
                </div>
            </div>
        </div>
<?php } } ?>

<?php require_once 'template/footer.php'; ?>