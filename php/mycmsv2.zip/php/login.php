<?php 
$title = "Login Page";
require_once 'template/header.php'; 
require 'classes/Service.php';
require 'classes/Product.php';

$NameError = $PasswordError = "";
$name  = $password = "";
$found = false;
if(isset($_SESSION['id'],$_SESSION['name'],$_SESSION['role'])){
    echo "You're Already Logged";
    die();
};

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = trim(FilterString($_POST['name']));
    if(empty($name)){
        $NameError = "Your name is required";
    }

    $stmt = $mysqli->prepare("SELECT * FROM users WHERE name = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $result = $stmt->get_result();    

    if($result->num_rows == 0){ 
        $NameError = "Your name not found Try other one";
    }else{
       $password = trim(FilterString($_POST['password']));
        if(empty($password)){
            $PasswordError = "Your password is required";
        }else{
                $data = $result->fetch_assoc();
                if(password_verify($password, $data['password'])){
                    echo "Logged to your Account Succeefully";
                    $_SESSION['id'] = $data['id'];
                    $_SESSION['name'] = $data['name'];
                    $_SESSION['role'] = $data['role'];
                    $_SESSION['email'] = $data['email'];

                    if(isset($_POST['staylogge']) && $_POST['staylogge'] === 'agreed'){
                        $token = bin2hex(random_bytes(32));
                        $stmt = $mysqli->prepare("UPDATE users SET token = ? WHERE id = ?");
                        $stmt->bind_param("si", $token, $data['id']);
                        $stmt->execute();
                        $stmt->close();
                        setcookie("staylogge", $token, time() + (86400 * 30), "/");
                    }else{
                        $stmt = $mysqli->prepare("UPDATE users SET token = ? WHERE id = ?");
                        $d = "";
                        $stmt->bind_param("si", $d, $data['id']);
                        $stmt->execute();
                        $stmt->close();
                    }
                    header("Location: /php/index.php");

                }else{
                    echo "invaild password";
            }
        }
    }




};


?>

<h1>Login</h1>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" value="<?php echo $name?>" id="name" name="name">
        <span class="text-danger"><?php echo $NameError?></span>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" value="<?php echo $password?>" id="password" name="password">
        <span class="text-danger"><?php echo $PasswordError?></span>
    </div>

    <div class="mb-3">
        <input type="checkbox" id="staylogge" name="staylogge" value="agreed">
        <label for="staylogge">Do you want Stay Logged?</label>
    </div>

    <div class="mb-3">
        <button type="submit" class="btn btn-success">Submit</button>
        <a href="/php/register.php">Don't have Account?</a>
    </div>
</form>

<?php require_once 'template/footer.php'; ?>