#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int write_what_where();
void shell(void);

int write_what_where(){
	long long what;
	long long *where;
	printf("Write What: ");
	scanf("%llu",&what);
	printf("Where: ");
	scanf("%llu",&where);
	*where = what;
	return 0;
}

void shell(void){
	system("/bin/sh");
}

int main(){
	write_what_where();
	return 0;
}
