<?php 
$title = "Logout Page";
require_once 'template/header.php'; 
require 'classes/Service.php';
require 'classes/Product.php';

session_unset();
session_destroy();
setcookie("staylogge", "", time() - 3600, "/");
header("Location: /php/index.php");
?>

<?php require_once 'template/footer.php'; ?>